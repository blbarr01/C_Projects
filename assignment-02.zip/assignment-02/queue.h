#ifndef QUEUE
#define QUEUE
#include<stdbool.h>
#include "process.h"



// create nodes for the queue
struct Node {
    process *nodeProcess;
    struct Node *next;
};

typedef struct node node; 

struct Queue
{
    node *head, *tail;
};

typedef struct Queue queue;


node *newNode(process *nprocess);
queue *createQueue();
void enQueue(queue *q, process *p);
process* deQueue(queue *q);
void peek(queue *q);
bool isQueueEmpty(queue *q);
void printQueue(queue *q);

#endif 