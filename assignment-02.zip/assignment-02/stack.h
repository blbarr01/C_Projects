#include "process.h"
#include <stdbool.h>

#ifndef STACK_H
#define STACK_H
typedef struct 
{
    int top, capacity;
    process *activeProcess; 
} stack;

stack *createStack(int capacity);
bool isStackEmpty(stack* s);
bool isStackFull(stack *s);
void push(stack *s, process *p);
void pop(stack *s);

#endif