#include<stdbool.h>
#ifndef PROCESS_H
#define PROCESS_H


struct process
{
    int pid,
        arrival,
        totalCpu,
        totalRemaining,
        start,  
        finish,
        turnAround;

    bool is_finished,
        in_progress,
        is_ready;

};

typedef struct process process; 

process* quickProcesses(int n);
void printProcess(process *p);

#endif