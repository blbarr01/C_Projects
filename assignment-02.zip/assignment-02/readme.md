i couldn't figure out how to get this to work. 
i should have asked for help sooner. 
i should have started sooner 


my plan was to create a block of processes. 
load them into a queue 
pop the processes onto a stack to simulate a process being on a cpu  

but nothing worked out 


running make in the command line will create an executable assignment-02.exe.
this executable can be run from the command line 