#include <stdbool.h>
#include<time.h>
#include<stdlib.h>
#include<stdlib.h>
#include<stdio.h>
struct process
{
    int pid,
        arrival,
        totalCpu,
        totalRemaining,
        start,  
        finish,
        turnAround;

    bool is_finished,
        in_progress,
        is_ready;

};

typedef struct process process; 

process* quickProcesses(int n){
    //printf("you reached the qprocess thread %d \n", n);
    process *jobs = (process*)malloc(sizeof(process) * n);
    time_t t;
    srand((unsigned) time(&t));
    for(int i = 0; i < n; i++){
        jobs[i].pid = i; 
        jobs[i].arrival = (rand() % 8);
        jobs[i].totalCpu = (rand() % 16) +1; 
    }   
    return jobs;

}


void printProcess(process *p){
    printf("process id: %d total cpu %d \n", p->pid, p->totalCpu);
}